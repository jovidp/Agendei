<?php

/**
 * CRUD de profissionais e vinculo com os servicos executados.
 */
// Carrega as configurações, a sessão e as funções compartilhadas antes de processar a página.
require_once __DIR__ . '/../config/config.php';

// Restringe esta página a administradores autenticados.
exigirLogin('admin');

$erros = [];

// Processa o formulário enviado antes de montar o HTML da página.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Confere o token da sessão antes de aceitar alterações enviadas pelo formulário.
    exigirCsrf();

    $acao           = post('acao');
    $idProfissional = (int) post('id_profissional');

    // Valida os campos antes de criar ou atualizar o cadastro.
    if ($acao === 'salvar') {
        $profissional = $idProfissional > 0 ? Profissional::porId($idProfissional) : null;

        $nome          = post('nome');
        $email         = mb_strtolower(post('email'));
        $telefone      = apenasNumeros(post('telefone'));
        $especialidade = post('especialidade');
        $senha         = post('senha');
        $status        = post('status') === 'inativo' ? 'inativo' : 'ativo';
        $servicos      = array_map('intval', (array) ($_POST['servicos'] ?? []));
        $podeBloquear  = post('pode_bloquear_agenda') === '1';
        $idFilial      = (int) post('id_filial');

        // Cadastro novo com e-mail conhecido: a pessoa ja existe (cliente ou
        // profissional em outra empresa, ou administradora desta) e ganha o
        // vinculo aqui, sem senha nova e sem que os dados dela sejam reescritos.
        $pessoaExistente = !$profissional && validarEmail($email) ? Usuario::pessoaPorEmail($email) : null;
        // Na edicao, nome, e-mail e senha so podem ser alterados pela empresa se
        // a pessoa nao tiver vinculo em outro lugar; fora disso esses dados sao
        // dela, valem nas outras empresas, e so ela os altera no proprio perfil.
        $pessoaCompartilhada = $profissional && !Usuario::pertenceSoAqui((int) $profissional['id_usuario']);
        $dadosDaPessoa = !$pessoaExistente && !$pessoaCompartilhada;

        if ($dadosDaPessoa && (mb_strlen($nome) < 5 || !str_contains($nome, ' '))) {
            $erros[] = 'Informe o nome completo do profissional.';
        }
        if (!validarEmail($email)) {
            $erros[] = 'Informe um e-mail valido.';
        } elseif ($profissional && !$pessoaCompartilhada && Usuario::emailEmUso($email, (int) $profissional['id_usuario'])) {
            $erros[] = 'Este e-mail ja esta cadastrado em outra conta.';
        } elseif ($pessoaExistente && Vinculo::porPessoaEmpresaTipo(Contexto::id(), (int) $pessoaExistente['id_usuario'], 'profissional') !== null) {
            $erros[] = 'Esta pessoa ja e profissional deste estabelecimento.';
        }
        if ($dadosDaPessoa && $telefone !== '' && !in_array(strlen($telefone), [10, 11], true)) {
            $erros[] = 'Informe um telefone valido com DDD.';
        }
        if (!$profissional && !$pessoaExistente && !validarSenha($senha)) {
            $erros[] = 'Defina uma senha de acesso com no minimo 6 caracteres.';
        }
        if ($profissional && !$pessoaCompartilhada && $senha !== '' && !validarSenha($senha)) {
            $erros[] = 'A nova senha deve ter no minimo 6 caracteres.';
        }
        if ($servicos === []) {
            $erros[] = 'Selecione ao menos um servico executado pelo profissional.';
        }
        // Todo profissional pertence a uma filial do estabelecimento.
        if ($idFilial <= 0 || Filial::porId($idFilial) === null) {
            $erros[] = 'Escolha a filial do profissional.';
        }

        // O teto do plano vale para equipe nova e para reativacao: os dois
        // aumentam o numero de profissionais ativos. Editar quem ja esta
        // ativo continua liberado.
        $viraAtivo = !$profissional || ($status === 'ativo' && ($profissional['status'] ?? '') !== 'ativo');
        if ($viraAtivo) {
            $limitePlano = Plano::bloqueio('profissionais', Contexto::id());
            if ($limitePlano !== null) {
                $erros[] = $limitePlano;
            }
        }

        if ($erros === []) {
            try {
                if ($profissional) {
                    if (!$pessoaCompartilhada) {
                        Usuario::atualizar((int) $profissional['id_usuario'], [
                            'nome'     => $nome,
                            'email'    => $email,
                            'telefone' => $telefone,
                        ]);
                        if ($senha !== '') {
                            Usuario::atualizarSenha((int) $profissional['id_usuario'], $senha);
                        }
                    }
                    Vinculo::alterarStatus((int) $profissional['id_vinculo'], $status);

                    Profissional::atualizar($idProfissional, [
                        'id_filial'            => $idFilial,
                        'especialidade'        => $especialidade,
                        'bio'                  => post('bio'),
                        'pode_bloquear_agenda' => $podeBloquear,
                    ]);
                    Profissional::definirServicos($idProfissional, $servicos);

                    definirFlash('sucesso', 'Profissional atualizado com sucesso.');
                } else {
                    Profissional::criar([
                        'id_usuario'           => $pessoaExistente ? (int) $pessoaExistente['id_usuario'] : 0,
                        'nome'                 => $nome,
                        'email'                => $email,
                        'senha'                => $senha,
                        'telefone'             => $telefone,
                        'id_filial'            => $idFilial,
                        'especialidade'        => $especialidade,
                        'bio'                  => post('bio'),
                        'status'               => $status,
                        'pode_bloquear_agenda' => $podeBloquear,
                        'servicos'             => $servicos,
                    ]);

                    definirFlash('sucesso', $pessoaExistente
                        ? 'Profissional vinculado: ' . $pessoaExistente['nome'] . ' ja tinha conta e entra com a senha de sempre. Configure o expediente em Horarios.'
                        : 'Profissional cadastrado com sucesso. Configure o expediente em Horarios.');
                }

                redirecionar('admin/profissionais.php');
            } catch (Throwable $erro) {
                error_log('Falha ao salvar profissional: ' . $erro->getMessage());
                $erros[] = 'Nao foi possivel salvar o profissional. Tente novamente.';
            }
        }
    }

    // Trata a mudança de status solicitada pelo formulário.
    if ($acao === 'status' && $idProfissional > 0) {
        $profissional = Profissional::porId($idProfissional);
        if ($profissional) {
            $novoStatus = post('status') === 'ativo' ? 'ativo' : 'inativo';

            // Reativar ocupa uma vaga igual a de um cadastro novo: sem esta
            // conferencia, desativar e reativar driblaria o teto do plano.
            $limitePlano = $novoStatus === 'ativo' ? Plano::bloqueio('profissionais', Contexto::id()) : null;

            if ($limitePlano !== null) {
                definirFlash('erro', $limitePlano);
            } else {
                Vinculo::alterarStatus((int) $profissional['id_vinculo'], $novoStatus);
                definirFlash('sucesso', $novoStatus === 'ativo' ? 'Profissional ativado.' : 'Profissional desativado.');
            }
        }
        redirecionar('admin/profissionais.php');
    }

    // Confere o registro e as regras aplicáveis antes da exclusão.
    if ($acao === 'excluir' && $idProfissional > 0) {
        $profissional = Profissional::porId($idProfissional);
        $totalAgendamentos = Agendamento::contar(['id_profissional' => $idProfissional]);

        if (!$profissional) {
            definirFlash('erro', 'Profissional nao encontrado.');
        } elseif ($totalAgendamentos > 0) {
            definirFlash('erro', 'Este profissional possui agendamentos registrados e nao pode ser excluido. Desative o cadastro.');
        } else {
            // Apaga o vinculo profissional (agenda, horarios e servicos caem em
            // cascata); a pessoa so some se nao tiver vinculo em outra empresa.
            Vinculo::excluir((int) $profissional['id_vinculo']);
            definirFlash('sucesso', 'Profissional excluido.');
        }

        redirecionar('admin/profissionais.php');
    }
}

$acaoTela = get('acao');
$edicao   = null;
$servicosVinculados = [];

if ($acaoTela === 'editar') {
    $edicao = Profissional::porId((int) get('id'));
    if (!$edicao) {
        definirFlash('erro', 'Profissional nao encontrado.');
        redirecionar('admin/profissionais.php');
    }
    $servicosVinculados = Profissional::idsServicos((int) $edicao['id_profissional']);
}
// Pessoa com vinculo em outra empresa: nome, e-mail, telefone e senha sao dela.
$edicaoCompartilhada = $edicao && !Usuario::pertenceSoAqui((int) $edicao['id_usuario']);
$soLeitura = $edicaoCompartilhada ? ' readonly' : '';

$formularioAberto = in_array($acaoTela, ['novo', 'editar'], true) || $erros !== [];

if ($erros !== [] && isset($_POST['servicos'])) {
    $servicosVinculados = array_map('intval', (array) $_POST['servicos']);
}

$busca  = get('busca');
$status = get('status');
$lista  = Profissional::listar(array_filter(['busca' => $busca, 'status' => $status]));
$servicosDisponiveis = Servico::listar();

// Filiais para o select e um mapa id => nome para a listagem (uma consulta so).
$filiais      = Filial::listar();
$nomesFiliais = array_column($filiais, 'nome', 'id_filial');
$semFiliais   = Filial::total() === 0;

// Na edicao marca a filial atual; no cadastro, se ha uma so, ja vem escolhida.
$filialSelecionada = (int) ($edicao['id_filial'] ?? post('id_filial'));
if ($filialSelecionada <= 0 && count($filiais) === 1) {
    $filialSelecionada = (int) $filiais[0]['id_filial'];
}

// Sem filial nao ha onde lotar o profissional: o formulario de criacao fica travado.
$formularioBloqueado = $semFiliais && !$edicao;
$bloqueio            = $formularioBloqueado ? ' disabled' : '';

// Define o título e os demais dados de apresentação utilizados pelo cabeçalho.
$tituloPagina  = 'Profissionais';
$subtituloTopo = 'Equipe, servicos executados e acesso ao sistema';
$acoesTopo     = $formularioAberto
    ? '<a href="' . url('admin/profissionais.php') . '" class="btn btn-contorno btn-pequeno">Voltar para a lista</a>'
    : '<a href="' . url('admin/profissionais.php?acao=novo') . '" class="btn btn-pequeno">Novo profissional</a>';

// Renderiza a estrutura comum do painel após preparar os dados desta tela.
require_once RAIZ . '/includes/painel_header.php';
?>

<?php if ($erros !== []): ?>
    <div class="alerta alerta-erro">
        <div>
            <span class="alerta-texto">Corrija os itens abaixo:</span>
            <ul><?php foreach ($erros as $mensagem): ?><li><?= e($mensagem) ?></li><?php endforeach; ?></ul>
        </div>
    </div>
<?php endif; ?>

<?php if ($semFiliais): ?>
    <div class="alerta alerta-aviso" role="status">
        <span class="alerta-texto">
            Cadastre uma filial antes de cadastrar profissionais: cada profissional pertence a uma unidade.
            <a href="<?= url('admin/filiais.php') ?>">Cadastrar filial</a>
        </span>
    </div>
<?php endif; ?>

<?php if ($formularioAberto): ?>

    <div class="cartao">
        <div class="cartao-cabecalho">
            <h3><?= $edicao ? 'Editar profissional' : 'Novo profissional' ?></h3>
        </div>
        <div class="cartao-corpo">
            <?php /* Formulário de alteração: os dados serão validados novamente pelo servidor. */ ?><form method="post">
                <?= campoCsrf() ?>
                <input type="hidden" name="acao" value="salvar">
                <input type="hidden" name="id_profissional" value="<?= (int) ($edicao['id_profissional'] ?? 0) ?>">

                <div class="linha-campos">
                    <div class="campo">
                        <label for="nome">Nome completo <span class="obrigatorio">*</span></label>
                        <input type="text" id="nome" name="nome" maxlength="120"
                            value="<?= e($edicao['nome'] ?? post('nome')) ?>" required<?= $bloqueio ?><?= $soLeitura ?>>
                        <?php if ($edicaoCompartilhada): ?>
                            <span class="ajuda-campo">Esta pessoa tambem tem conta em outro estabelecimento: nome, e-mail, telefone e senha sao dela e so ela os altera, no proprio perfil.</span>
                        <?php endif; ?>
                    </div>

                    <div class="campo">
                        <label for="especialidade">Especialidade</label>
                        <input type="text" id="especialidade" name="especialidade" maxlength="120"
                            value="<?= e($edicao['especialidade'] ?? post('especialidade')) ?>"
                            placeholder="Ex.: Barbeiro, Cabeleireira"<?= $bloqueio ?>>
                    </div>
                </div>

                <div class="linha-campos">
                    <div class="campo">
                        <label for="id_filial">Filial <span class="obrigatorio">*</span></label>
                        <select id="id_filial" name="id_filial" required<?= $bloqueio ?>>
                            <option value="">Selecione a filial</option>
                            <?php foreach ($filiais as $filial): ?>
                                <option value="<?= (int) $filial['id_filial'] ?>" <?= $filialSelecionada === (int) $filial['id_filial'] ? 'selected' : '' ?>>
                                    <?= e($filial['nome']) ?><?= $filial['status'] === 'inativo' ? ' (inativa)' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <span class="ajuda-campo">Unidade em que o profissional atende.</span>
                    </div>
                </div>

                <div class="linha-campos">
                    <div class="campo">
                        <label for="email">E-mail de acesso <span class="obrigatorio">*</span></label>
                        <input type="email" id="email" name="email" maxlength="150"
                            value="<?= e($edicao['email'] ?? post('email')) ?>" required<?= $bloqueio ?><?= $soLeitura ?>>
                        <?php if (!$edicao): ?>
                            <span class="ajuda-campo">Se o e-mail ja tiver conta no Agendei, a pessoa e vinculada como profissional e entra com a senha que ja tem.</span>
                        <?php endif; ?>
                    </div>

                    <div class="campo">
                        <label for="telefone">Telefone</label>
                        <input type="tel" id="telefone" name="telefone" data-mascara="telefone" inputmode="numeric"
                            value="<?= e($edicao ? formatarTelefone($edicao['telefone']) : post('telefone')) ?>"<?= $bloqueio ?><?= $soLeitura ?>>
                    </div>
                </div>

                <div class="linha-campos">
                    <div class="campo">
                        <?php if ($edicaoCompartilhada): ?>
                            <label>Senha de acesso</label>
                            <p class="texto-secundario sem-margem">A senha e da pessoa e vale em todas as empresas dela: so ela a troca.</p>
                        <?php else: ?>
                            <label for="senha"><?= $edicao ? 'Nova senha (opcional)' : 'Senha de acesso' ?></label>
                            <input type="password" id="senha" name="senha" autocomplete="new-password"<?= $bloqueio ?>>
                            <span class="ajuda-campo"><?= $edicao ? 'Deixe em branco para manter a senha atual.' : 'Minimo de 6 caracteres. Dispensada quando o e-mail ja tem conta no Agendei.' ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="campo">
                        <label for="status">Status</label>
                        <select id="status" name="status"<?= $bloqueio ?>>
                            <option value="ativo" <?= ($edicao['status'] ?? 'ativo') === 'ativo' ? 'selected' : '' ?>>Ativo</option>
                            <option value="inativo" <?= ($edicao['status'] ?? '') === 'inativo' ? 'selected' : '' ?>>Inativo</option>
                        </select>
                        <span class="ajuda-campo">Profissionais inativos nao aparecem para os clientes.</span>
                    </div>
                </div>

                <div class="campo">
                    <label for="bio">Apresentacao</label>
                    <textarea id="bio" name="bio" maxlength="400"<?= $bloqueio ?>><?= e($edicao['bio'] ?? post('bio')) ?></textarea>
                </div>

                <fieldset>
                    <legend>Servicos executados <span class="obrigatorio">*</span></legend>

                    <?php if ($servicosDisponiveis === []): ?>
                        <p class="texto-secundario sem-margem">
                            Nenhum servico cadastrado.
                            <a href="<?= url('admin/servicos.php?acao=novo') ?>">Cadastre um servico</a> antes de continuar.
                        </p>
                    <?php else: ?>
                        <div class="linha-campos-3">
                            <?php foreach ($servicosDisponiveis as $servico): ?>
                                <div class="campo-checkbox">
                                    <input type="checkbox" id="servico<?= (int) $servico['id_servico'] ?>"
                                        name="servicos[]" value="<?= (int) $servico['id_servico'] ?>"
                                        <?= in_array((int) $servico['id_servico'], $servicosVinculados, true) ? 'checked' : '' ?><?= $bloqueio ?>>
                                    <label for="servico<?= (int) $servico['id_servico'] ?>">
                                        <?= e($servico['nome']) ?>
                                        <?= $servico['status'] === 'inativo' ? ' (inativo)' : '' ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </fieldset>

                <div class="campo-checkbox">
                    <input type="checkbox" id="pode_bloquear_agenda" name="pode_bloquear_agenda" value="1"
                        <?= (!$edicao || !empty($edicao['pode_bloquear_agenda'])) ? 'checked' : '' ?><?= $bloqueio ?>>
                    <label for="pode_bloquear_agenda">Permitir que o profissional bloqueie a propria agenda</label>
                </div>

                <div class="grupo-botoes">
                    <button type="submit" class="btn"<?= $bloqueio ?>><?= $edicao ? 'Salvar alteracoes' : 'Cadastrar profissional' ?></button>
                    <a href="<?= url('admin/profissionais.php') ?>" class="btn btn-contorno">Cancelar</a>
                </div>
            </form>
        </div>
    </div>

<?php endif; ?>

<div class="cartao">
    <?php /* Filtros enviados na URL para permitir atualizar e compartilhar a consulta. */ ?><form method="get" class="barra-filtros">
        <input type="hidden" name="estabelecimento" value="<?= e(Contexto::slug()) ?>">
        <div class="campo campo-busca">
            <label for="busca">Buscar profissional</label>
            <input type="search" id="busca" name="busca" value="<?= e($busca) ?>" placeholder="Nome, e-mail ou especialidade">
        </div>

        <div class="campo">
            <label for="filtroStatus">Status</label>
            <select id="filtroStatus" name="status" data-envia-ao-mudar>
                <option value="">Todos</option>
                <option value="ativo" <?= $status === 'ativo' ? 'selected' : '' ?>>Ativos</option>
                <option value="inativo" <?= $status === 'inativo' ? 'selected' : '' ?>>Inativos</option>
            </select>
        </div>

        <div class="campo">
            <button type="submit" class="btn btn-contorno">Filtrar</button>
        </div>
    </form>

    <?php if ($lista === []): ?>
        <div class="estado-vazio">
            <strong>Nenhum profissional cadastrado.</strong>
            <p>Cadastre a equipe para liberar os agendamentos.</p>
            <a href="<?= url('admin/profissionais.php?acao=novo') ?>" class="btn margem-topo">Novo profissional</a>
        </div>
    <?php else: ?>
        <div class="tabela-area">
            <?php /* Tabela de apresentação dos registros retornados pela consulta. */ ?><table class="tabela">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Profissional</th>
                        <th>Contato</th>
                        <th>Especialidade</th>
                        <th>Filial</th>
                        <th>Servicos</th>
                        <th>Status</th>
                        <th class="coluna-acoes">Acoes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lista as $profissional): ?>
                        <tr>
                            <td><?= (int) $profissional['id_profissional'] ?></td>
                            <td>
                                <span class="celula-principal"><?= e($profissional['nome']) ?></span>
                                <span class="celula-secundaria">Desde <?= formatarData($profissional['data_cadastro']) ?></span>
                            </td>
                            <td>
                                <?= e($profissional['email']) ?>
                                <span class="celula-secundaria"><?= e(formatarTelefone($profissional['telefone'])) ?></span>
                            </td>
                            <td><?= e($profissional['especialidade'] ?: '-') ?></td>
                            <td><?= e($nomesFiliais[(int) $profissional['id_filial']] ?? '-') ?></td>
                            <td><?= (int) $profissional['total_servicos'] ?></td>
                            <td><?= badgeStatus($profissional['status']) ?></td>
                            <td class="coluna-acoes">
                                <a href="<?= url('admin/horarios.php?id_profissional=' . (int) $profissional['id_profissional']) ?>"
                                    class="btn btn-contorno btn-pequeno">Horarios</a>
                                <a href="<?= url('admin/profissionais.php?acao=editar&id=' . (int) $profissional['id_profissional']) ?>"
                                    class="btn btn-contorno btn-pequeno">Editar</a>

                                <?php /* Formulário de alteração: os dados serão validados novamente pelo servidor. */ ?><form method="post" style="display:inline">
                                    <?= campoCsrf() ?>
                                    <input type="hidden" name="acao" value="status">
                                    <input type="hidden" name="id_profissional" value="<?= (int) $profissional['id_profissional'] ?>">
                                    <input type="hidden" name="status" value="<?= $profissional['status'] === 'ativo' ? 'inativo' : 'ativo' ?>">
                                    <button type="submit" class="btn btn-contorno btn-pequeno">
                                        <?= $profissional['status'] === 'ativo' ? 'Desativar' : 'Ativar' ?>
                                    </button>
                                </form>

                                <?php if (Agendamento::contar(['id_profissional' => (int) $profissional['id_profissional']]) === 0): ?>
                                    <?php /* Formulário de alteração: os dados serão validados novamente pelo servidor. */ ?><form method="post" style="display:inline">
                                        <?= campoCsrf() ?>
                                        <input type="hidden" name="acao" value="excluir">
                                        <input type="hidden" name="id_profissional" value="<?= (int) $profissional['id_profissional'] ?>">
                                        <button type="submit" class="btn btn-perigo btn-pequeno"
                                            data-confirmar="Excluir o cadastro de <?= e($profissional['nome']) ?>? O acesso ao sistema sera removido."
                                            data-confirmar-titulo="Excluir profissional"
                                            data-confirmar-rotulo="Excluir">
                                            Excluir
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once RAIZ . '/includes/painel_footer.php'; ?>