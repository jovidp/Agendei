<?php
/** Cadastro publico com demonstracao de sete dias e identidade unica. */
define('ENTRADA_LOCAL', true);
define('PAGINA_PRODUTO', true);
require_once __DIR__ . '/config/config.php';

bloquearSeLogado();

$erros = [];
$dados = [
    'estabelecimento' => '',
    'slug'            => '',
    'nome'            => '',
    'email'           => '',
    'telefone'        => '',
    'mensagem'        => '',
];

// Cadastro iniciado pelo Google (google_login.php): nome e e-mail do
// responsavel ja vem confirmados e preenchidos. A confirmacao vale so para
// esta tela e por pouco tempo (Google::cadastroPendente).
if (get('google') === 'cancelar') {
    Google::limparCadastro();
    redirecionar('cadastro_empresa.php');
}
$googleCadastro = Google::cadastroPendente('cadastro_empresa');
if (is_array($googleCadastro) && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $dados['nome']  = (string) ($googleCadastro['nome'] ?? '');
    $dados['email'] = (string) ($googleCadastro['email'] ?? '');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigirCsrf();

    // Limita a criacao de empresas de demonstracao por origem.
    $bloqueio = conferirBloqueio(['cadastro_empresa_ip' => ipCliente()]);
    if ($bloqueio !== '') {
        $erros[] = $bloqueio;
    }
    anotarFalha('cadastro_empresa_ip', ipCliente());

    foreach (array_keys($dados) as $campo) {
        $dados[$campo] = trim(post($campo));
    }
    $dados['slug']  = mb_strtolower($dados['slug']);
    $dados['email'] = mb_strtolower($dados['email']);
    $senha          = post('senha');
    $confirmacao    = post('confirmar_senha');
    $telefone       = apenasNumeros($dados['telefone']);

    // E-mail que ja tem conta: a pessoa existe e sera vinculada como responsavel,
    // com a senha que ja tem. A senha digitada e a prova de que o e-mail e dela;
    // o Google, quando confirmou o e-mail nesta mesma tela, tambem serve.
    $pessoaExistente     = validarEmail($dados['email']) ? Usuario::pessoaPorEmail($dados['email']) : null;
    $confirmadoPeloGoogle = is_array($googleCadastro) && ($googleCadastro['email'] ?? '') === $dados['email'];

    if (mb_strlen($dados['estabelecimento']) < 2 || mb_strlen($dados['estabelecimento']) > 120) {
        $erros[] = 'Informe o nome da empresa.';
    }
    if (!preg_match('/^[a-z0-9](?:[a-z0-9-]{1,78}[a-z0-9])$/D', $dados['slug'])) {
        $erros[] = 'O endereço deve ter de 3 a 80 letras minúsculas, números ou hifens.';
    }
    if (!validarNomeSobrenome($dados['nome'])) {
        $erros[] = 'Informe o nome e o sobrenome do responsável.';
    }
    if (!validarEmail($dados['email'])) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if ($telefone === '' || !(validarTelefoneBr($telefone) || validarTelefoneBr($telefone, true))) {
        $erros[] = 'Informe um telefone ou WhatsApp com DDD.';
    }
    if (mb_strlen($dados['mensagem']) > 255) {
        $erros[] = 'A mensagem deve ter no máximo 255 caracteres.';
    }
    if ($pessoaExistente !== null) {
        if (!$confirmadoPeloGoogle && !password_verify($senha, $pessoaExistente['senha_hash'])) {
            $erros[] = 'Este e-mail já tem conta no Agendei. Informe a senha dela para vincular a empresa nova; a senha continua a mesma.';
        }
    } else {
        if (!validarSenha($senha)) {
            $erros[] = 'A senha deve ter pelo menos 6 caracteres.';
        }
        if ($senha !== $confirmacao) {
            $erros[] = 'As senhas não conferem.';
        }
    }
    // Aceite dos Termos e da Politica: sem ele a conta nao e criada (o aceite e gravado com a versao).
    if (post('aceite') !== '1') {
        $erros[] = 'Para criar a conta, aceite os Termos de Uso e a Política de Privacidade.';
    }
    if ($erros === [] && Solicitacao::slugEmUso($dados['slug'])) {
        $erros[] = 'Este endereço já está em uso. Escolha outro.';
    }

    if ($erros === []) {
        try {
            $idEmpresa = Estabelecimento::contratar([
                'estabelecimento' => $dados['estabelecimento'],
                'slug'            => $dados['slug'],
                'nome'            => $dados['nome'],
                'email'           => $dados['email'],
                'senha'           => $senha,
                'telefone'        => $telefone,
                'mensagem'        => $dados['mensagem'],
                'iniciar_demo'    => true,
            ]);
            LogMaster::registrar('estabelecimento_criado', [
                'estabelecimento' => $idEmpresa,
                'estabelecimento_nome' => $dados['estabelecimento'],
                'alvo' => $dados['email'],
                'detalhe' => 'demonstração de 7 dias',
            ]);
            Legal::registrarAceite($dados['email']);
            // Conta nova: manda o codigo para confirmar o e-mail. Quem ja tinha conta continua como estava.
            if ($pessoaExistente === null) VerificacaoEmail::aposCadastro($dados['email'], $confirmadoPeloGoogle);
            // Na demonstracao a empresa experimenta o plano padrao; escolhe o dela em Assinatura.
            try {
                $planoInicial = Plano::porNome(Plano::PADRAO_CADASTRO);
                if ($planoInicial !== null) Plano::atribuir($idEmpresa, (int) $planoInicial['id_plano'], 'Plano da demonstração');
            } catch (Throwable $erroPlano) {
                error_log('Plano inicial não atribuído: ' . $erroPlano->getMessage());
            }
            limparFalhas('cadastro_empresa_ip', ipCliente());
            Google::limparCadastro();
            definirFlash('sucesso', 'Sua empresa foi criada. Você tem 7 dias de demonstração grátis.');
            redirecionar('login.php?estabelecimento=' . rawurlencode($dados['slug']));
        } catch (PDOException $erro) {
            error_log('Falha no cadastro de empresa: ' . $erro->getMessage());
            $erros[] = $erro->getCode() === '23000'
                ? 'Este endereço já está em uso. Escolha outro.'
                : 'Não foi possível enviar o cadastro. Tente novamente.';
        } catch (Throwable $erro) {
            error_log('Falha no cadastro de empresa: ' . $erro->getMessage());
            $erros[] = 'Não foi possível enviar o cadastro. Tente novamente.';
        }
    }
}

$tituloPagina = 'Cadastrar empresa | ' . NOME_SISTEMA;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($tituloPagina) ?></title>
    <link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
    <link rel="stylesheet" href="<?= url('assets/css/login.css') ?>">
    <?php require RAIZ . '/includes/tema.php'; ?>
</head>
<body class="pagina-autenticacao">

<div class="autenticacao-area">
    <div class="autenticacao-caixa caixa-larga">
        <?php /* Painel do produto, o mesmo da entrada geral. */ ?>
        <div class="autenticacao-apresentacao apresentacao-marca">
            <?= marcaSistema(36, true) ?>
            <h2 class="marca-slogan"><?= e(MARCA_SLOGAN) ?></h2>
        </div>

        <div class="autenticacao-formulario">

                <a href="<?= e(urlInicio()) ?>" class="voltar-site">&larr; Voltar ao início</a>

                <h1>Cadastrar minha empresa</h1>
                <p class="subtitulo">Comece agora com 7 dias grátis. Depois, planos a partir de <?= formatarMoeda(Plano::menorPreco()) ?> por mês.</p>

                <?php /* Os dois cadastros do Agendei se confundem; este diz qual e e aponta o outro. */ ?>
                <p class="aviso-tipo-cadastro">
                    <strong>Cadastro de estabelecimento.</strong>
                    Cria a empresa e a sua conta de administrador, liberadas depois da aprovação.
                    Quer só marcar um horário? <a href="<?= url('criar_conta.php#cliente') ?>">Crie uma conta de cliente</a>.
                </p>

                <?php exibirFlash(); ?>

                <?php if ($erros !== []): ?>
                    <div class="alerta alerta-erro" role="alert"><ul><?php foreach ($erros as $mensagem): ?><li><?= e($mensagem) ?></li><?php endforeach; ?></ul></div>
                <?php endif; ?>

                <?php if (is_array($googleCadastro)): ?>
                    <div class="alerta alerta-info">
                        <span class="alerta-texto">E-mail <strong><?= e((string) $googleCadastro['email']) ?></strong> confirmado pelo Google. Complete os dados da empresa.
                            <a href="<?= url('cadastro_empresa.php?google=cancelar') ?>">Cadastrar sem o Google</a></span>
                    </div>
                <?php elseif (Google::configurado()): ?>
                    <?php /* Formulario proprio, fora do cadastro. Dentro dele o botao do Google seria o primeiro
                             botao de envio, e o Enter em qualquer campo levaria ao Google em vez de enviar o
                             cadastro. O Google confirma o e-mail e devolve nome e e-mail preenchidos. */ ?>
                    <form method="post" action="<?= url('google_login.php') ?>" id="formCadastroEmpresaGoogle">
                        <?= campoCsrf() ?>
                        <input type="hidden" name="origem" value="cadastro_empresa">
                        <button type="submit" class="btn btn-contorno btn-bloco btn-grande btn-google" name="acao" value="google">
                            <?= iconeGoogle() ?>
                            Cadastrar com o Google
                        </button>
                        <span class="ajuda-campo">Confirma seu e-mail e já preenche seu nome e e-mail. O restante você completa abaixo.</span>
                    </form>
                    <div class="separador-ou"><span>ou preencha tudo</span></div>
                <?php endif; ?>

                <form method="post" id="formCadastroEmpresa" novalidate>
                    <?= campoCsrf() ?>

                    <div class="linha-campos">
                        <div class="campo">
                            <label for="estabelecimento">Nome da empresa</label>
                            <input type="text" id="estabelecimento" name="estabelecimento" value="<?= e($dados['estabelecimento']) ?>"
                                   maxlength="120" required autofocus>
                            <span class="mensagem-campo"></span>
                        </div>
                        <div class="campo">
                            <label for="slug">Endereço da empresa</label>
                            <input type="text" id="slug" name="slug" value="<?= e($dados['slug']) ?>"
                                   maxlength="80" pattern="[a-z0-9][a-z0-9-]{1,78}[a-z0-9]" autocomplete="off" required>
                            <span class="mensagem-campo"></span>
                            <span class="ajuda-campo">Vira o link do seu login. Letras minúsculas, números e hifens.</span>
                        </div>
                    </div>

                    <div class="linha-campos">
                        <div class="campo">
                            <label for="nome">Nome e sobrenome</label>
                            <input type="text" id="nome" name="nome" value="<?= e($dados['nome']) ?>" maxlength="120" autocomplete="name" required>
                            <span class="mensagem-campo"></span>
                            <span class="ajuda-campo">De quem responde pela empresa. Ex.: Ana Souza.</span>
                        </div>
                        <div class="campo">
                            <label for="telefone">Telefone ou WhatsApp</label>
                            <input type="tel" id="telefone" name="telefone" value="<?= e($dados['telefone']) ?>" maxlength="20" autocomplete="tel"
                                   data-mascara="telefone" inputmode="numeric" placeholder="(00) 00000-0000" required>
                            <span class="mensagem-campo"></span>
                        </div>
                    </div>

                    <div class="campo">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" value="<?= e($dados['email']) ?>" maxlength="150" autocomplete="email" required>
                        <span class="mensagem-campo"></span>
                        <span class="ajuda-campo">Será o seu login e canal de contato. Se já tiver conta no Agendei, use a senha dela: a empresa nova entra na mesma conta.</span>
                    </div>

                    <div class="linha-campos">
                        <div class="campo">
                            <label for="senha">Senha</label>
                            <input type="password" id="senha" name="senha" minlength="6" autocomplete="new-password" required>
                            <span class="mensagem-campo"></span>
                            <span class="ajuda-campo">Nova, ou a da sua conta se o e-mail já tiver uma.</span>
                        </div>
                        <div class="campo">
                            <label for="confirmar_senha">Confirmar senha</label>
                            <input type="password" id="confirmar_senha" name="confirmar_senha" minlength="6" autocomplete="new-password" required>
                            <span class="mensagem-campo"></span>
                        </div>
                    </div>

                    <div class="campo">
                        <label for="mensagem">Conte um pouco sobre a empresa <span class="opcional">(opcional)</span></label>
                        <textarea id="mensagem" name="mensagem" rows="3" maxlength="255"><?= e($dados['mensagem']) ?></textarea>
                        <span class="mensagem-campo"></span>
                    </div>

                    <div class="campo campo-aceite">
                        <div class="campo-checkbox">
                            <input type="checkbox" id="aceite" name="aceite" value="1" <?= post('aceite') === '1' ? 'checked' : '' ?> required>
                            <label for="aceite">Li e aceito os <a href="<?= url('legal.php?pagina=termos') ?>" target="_blank" rel="noopener">Termos de Uso</a> e a <a href="<?= url('legal.php?pagina=privacidade') ?>" target="_blank" rel="noopener">Política de Privacidade</a> <span class="obrigatorio">*</span></label>
                        </div>
                        <span class="mensagem-campo"></span>
                    </div>

                    <div class="acoes-formulario">
                        <button type="submit" class="btn btn-bloco btn-grande">Enviar cadastro</button>
                    </div>
                </form>

                <p class="autenticacao-rodape">
                    Já tem conta? <a href="<?= url('entrar.php') ?>">Entrar</a>
                </p>
        </div>
    </div>
</div>

<?php require RAIZ . '/includes/assinatura_sistema.php'; ?>

<div id="notificacoes"></div>
<script src="<?= url('assets/js/main.js') ?>"></script>
<script src="<?= url('assets/js/cadastro_empresa.js') ?>"></script>
</body>
</html>
