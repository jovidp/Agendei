<?php
/**
 * Lista de agendamentos do cliente, com detalhes e cancelamento.
 */
// Carrega as configurações, a sessão e as funções compartilhadas antes de processar a página.
require_once __DIR__ . '/../config/config.php';

// Restringe esta página a clientes autenticados.
exigirLogin('cliente');

// Usa o perfil da sessão para consultar e alterar os dados do próprio cliente.
$idCliente = perfilId();

// Processa o formulário enviado antes de montar o HTML da página.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Confere o token da sessão antes de aceitar alterações enviadas pelo formulário.
    exigirCsrf();

    $acao          = post('acao', 'cancelar');
    $idAgendamento = (int) post('id_agendamento');
    $agendamento   = Agendamento::porId($idAgendamento);

    // Recusa tentativas de alterar agendamentos de outro cliente, mesmo com um ID válido.
    if (!$agendamento || (int) $agendamento['id_cliente'] !== $idCliente) {
        definirFlash('erro', 'Agendamento não encontrado.');
    } elseif ($acao === 'confirmar') {
        // O mesmo gesto do link do lembrete, para quem já está na conta.
        if (Confirmacao::confirmar($agendamento)) {
            definirFlash('sucesso', 'Presença confirmada. Até lá!');
        } else {
            definirFlash('erro', 'Este agendamento não pode mais ser confirmado.');
        }
    } elseif ($acao === 'pagar_sinal') {
        // Simulação: não há cobrança real; o sinal pendente passa direto a pago.
        if (Diferencial::pagarSinalSimulado($idAgendamento)) {
            definirFlash('sucesso', 'Pagamento do sinal simulado com sucesso.');
        } else {
            definirFlash('erro', 'Este agendamento não tem sinal pendente.');
        }
    } elseif (!Agendamento::clientePodeCancelar($agendamento)) {
        definirFlash('erro', 'Este agendamento não pode mais ser cancelado pelo painel. Entre em contato com o estabelecimento.');
    } else {
        Agendamento::cancelar($idAgendamento, usuarioId(), limitarTexto(post('motivo'), 200), true);
        $sinal = Diferencial::sinalDoAgendamento($idAgendamento);
        $destino = [
            'credito' => ' O sinal de ' . formatarMoeda($sinal['valor'] ?? 0) . ' ficou como crédito para o seu próximo agendamento.',
            'retido'  => ' O sinal de ' . formatarMoeda($sinal['valor'] ?? 0) . ' ficou com o estabelecimento.',
        ];
        definirFlash('sucesso', 'Agendamento cancelado.' . ($destino[$sinal['status'] ?? ''] ?? ''));
    }

    redirecionar('cliente/agendamentos.php');
}

$status      = get('status');
$porPagina   = 10;
// Mantém a página como inteiro positivo para calcular a listagem e sua navegação.
$pagina      = max(1, (int) get('pagina', '1'));

// Reúne os critérios usados para consultar a lista e calcular os totais.
$filtros = [
    'id_cliente' => $idCliente,
    'ordem'      => 'desc',
];

if (in_array($status, Agendamento::STATUS, true)) {
    $filtros['status'] = $status;
}

$total        = Agendamento::contar($filtros);
$agendamentos = Agendamento::listar($filtros + [
    'limite'       => $porPagina,
    'deslocamento' => ($pagina - 1) * $porPagina,
]);

$minutosSemPerda = Agendamento::minutosSemPerda();
$creditoSinal    = Diferencial::creditoSinal($idCliente);
// Sinal de cada reserva da página, para o botão de pagar e o relógio do prazo.
$sinais = [];
foreach (Diferencial::pagamentos($idCliente) as $pagamento) {
    if ($pagamento['tipo'] === 'sinal') {
        $sinais[(int) $pagamento['id_agendamento']] = $pagamento;
    }
}

// Pagamento avulso online faz parte dos diferenciais do plano.
$pagarOnline = Plano::temRecurso('diferenciais');

// Define o título e os demais dados de apresentação utilizados pelo cabeçalho.
$tituloPagina  = 'Meus agendamentos';
$subtituloTopo = 'Acompanhe e gerencie seus atendimentos';
$acoesTopo     = '<a href="' . url('cliente/agendar.php') . '" class="btn btn-pequeno">Novo agendamento</a>';

// Renderiza a estrutura comum do painel após preparar os dados desta tela.
require_once RAIZ . '/includes/painel_header.php';
?>

<?php if ($creditoSinal > 0): ?>
    <div class="alerta alerta-info">
        <span class="alerta-texto">Você tem <strong><?= formatarMoeda($creditoSinal) ?></strong> de sinal guardado como crédito. Ele paga o sinal do seu próximo agendamento.</span>
    </div>
<?php endif; ?>

<div class="cartao">
    <div class="barra-filtros">
        <?php /* Filtros enviados na URL para permitir atualizar e compartilhar a consulta. */ ?><form method="get" class="barra-filtros" style="padding:0;border:0;background:none;flex:1">
        <input type="hidden" name="estabelecimento" value="<?= e(Contexto::slug()) ?>">
            <div class="campo campo-busca">
                <label for="busca">Buscar</label>
                <input type="search" id="busca" placeholder="Serviço ou profissional"
                       data-busca-tabela="#tabelaAgendamentos" data-busca-vazio="#semResultado">
            </div>

            <div class="campo">
                <label for="status">Status</label>
                <select id="status" name="status" data-envia-ao-mudar>
                    <option value="">Todos</option>
                    <?php foreach (Agendamento::STATUS as $opcao): ?>
                        <option value="<?= e($opcao) ?>" <?= $status === $opcao ? 'selected' : '' ?>>
                            <?= e(ucfirst($opcao)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>

    <?php if ($agendamentos === []): ?>
        <div class="estado-vazio">
            <strong>Nenhum agendamento encontrado</strong>
            <p><?= $status !== '' ? 'Nenhum agendamento com este status.' : 'Você ainda não possui agendamentos.' ?></p>
            <a href="<?= url('cliente/agendar.php') ?>" class="btn margem-topo">Agendar agora</a>
        </div>
    <?php else: ?>
        <div class="tabela-area">
            <?php /* Tabela de apresentação dos registros retornados pela consulta. */ ?><table class="tabela" id="tabelaAgendamentos">
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Serviço</th>
                        <th>Profissional</th>
                        <th>Horário</th>
                        <th>Status</th>
                        <th>Valor</th>
                        <th class="coluna-acoes">Acoes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($agendamentos as $agendamento): ?>
                        <?php
                        $sinal      = $sinais[(int) $agendamento['id_agendamento']] ?? null;
                        $sinalPago  = $sinal !== null && $sinal['status'] === 'pago';
                        $restante   = Agendamento::prazoSemPerda($agendamento) - time();
                        $reaproveitado = $sinalPago && str_starts_with((string) $sinal['referencia'], Diferencial::PREFIXO_CREDITO);
                        if (!$sinalPago) {
                            $avisoCancelamento = '';
                        } elseif ($restante > 0 && !$reaproveitado) {
                            $avisoCancelamento = 'O sinal de ' . formatarMoeda($sinal['valor']) . ' fica como crédito para o seu próximo agendamento.';
                        } else {
                            $avisoCancelamento = 'O sinal de ' . formatarMoeda($sinal['valor']) . ' fica com o estabelecimento'
                                . ($reaproveitado ? ': ele já veio de um cancelamento anterior.' : ': faltam menos de ' . $minutosSemPerda . ' min para o horário.');
                        }
                        ?>
                        <tr data-linha>
                            <td class="celula-principal"><?= formatarData($agendamento['data_agendamento']) ?></td>
                            <td><?= e($agendamento['nome_servico']) ?></td>
                            <td><?= e($agendamento['nome_profissional']) ?></td>
                            <td>
                                <?= formatarHora($agendamento['hora_inicio']) ?>
                                <span class="celula-secundaria">até <?= formatarHora($agendamento['hora_fim']) ?></span>
                            </td>
                            <td>
                                <?= badgeStatus($agendamento['status']) ?>
                                <?php if ($sinalPago && !$reaproveitado && Agendamento::clientePodeCancelar($agendamento)): ?>
                                    <span class="celula-secundaria">
                                        <?php if ($restante > 0): ?>
                                            Cancele sem perder o sinal:
                                            <strong data-contagem="<?= (int) $restante ?>" data-contagem-fim="prazo encerrado"></strong>
                                        <?php else: ?>
                                            Prazo para cancelar sem perder o sinal encerrado.
                                        <?php endif; ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= formatarMoeda($agendamento['valor']) ?>
                                <?php if ($sinal !== null): ?>
                                    <span class="celula-secundaria">Sinal <?= formatarMoeda($sinal['valor']) ?> <?= badgeStatus($sinal['status']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="coluna-acoes">
                                <?php if ($pagarOnline && PagamentoAvulso::pagavel($agendamento, $idCliente)): ?>
                                    <a class="btn btn-pequeno" href="<?= url('cliente/pagar.php?agendamento=' . (int) $agendamento['id_agendamento']) ?>">Pagar agora</a>
                                <?php endif; ?>
                                <button type="button" class="btn btn-contorno btn-pequeno"
                                        data-modal="modalDetalhes"
                                        data-campo-servico="<?= e($agendamento['nome_servico']) ?>"
                                        data-campo-profissional="<?= e($agendamento['nome_profissional']) ?>"
                                        data-campo-data="<?= e(dataExtenso($agendamento['data_agendamento'])) ?>"
                                        data-campo-horario="<?= formatarHora($agendamento['hora_inicio']) ?> as <?= formatarHora($agendamento['hora_fim']) ?>"
                                        data-campo-duracao="<?= e(duracaoTexto((int) $agendamento['duracao_minutos'])) ?>"
                                        data-campo-valor="<?= formatarMoeda($agendamento['valor']) ?>"
                                        data-campo-status="<?= e(ucfirst($agendamento['status'])) ?>"
                                        data-campo-observacao="<?= e($agendamento['observacao'] ?: 'Sem observações.') ?>">
                                    Detalhes
                                </button>

                                <?php if ($agendamento['status'] === 'agendado' && !Agendamento::jaComecou($agendamento)): ?>
                                    <form method="post" class="formulario-inline">
                                        <?= campoCsrf() ?>
                                        <input type="hidden" name="acao" value="confirmar">
                                        <input type="hidden" name="id_agendamento" value="<?= (int) $agendamento['id_agendamento'] ?>">
                                        <button type="submit" class="btn btn-pequeno">Confirmar presença</button>
                                    </form>
                                <?php endif; ?>

                                <?php if (AMBIENTE === 'desenvolvimento' && $sinal !== null && $sinal['status'] === 'pendente' && Agendamento::clientePodeCancelar($agendamento)): ?>
                                    <form method="post" class="formulario-inline">
                                        <?= campoCsrf() ?>
                                        <input type="hidden" name="acao" value="pagar_sinal">
                                        <input type="hidden" name="id_agendamento" value="<?= (int) $agendamento['id_agendamento'] ?>">
                                        <button type="submit" class="btn btn-secundario btn-pequeno">Pagar sinal (simulação)</button>
                                    </form>
                                <?php endif; ?>

                                <?php if (Agendamento::clientePodeCancelar($agendamento)): ?>
                                    <button type="button" class="btn btn-perigo btn-pequeno"
                                            data-modal="modalCancelar"
                                            data-campo-id_agendamento="<?= (int) $agendamento['id_agendamento'] ?>"
                                            data-campo-aviso="<?= e($avisoCancelamento) ?>"
                                            data-campo-resumo="<?= e($agendamento['nome_servico']) ?> em <?= formatarData($agendamento['data_agendamento']) ?> às <?= formatarHora($agendamento['hora_inicio']) ?>">
                                        Cancelar
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div id="semResultado" class="estado-vazio oculto">
            <strong>Nenhum resultado para a busca</strong>
            <p>Tente outro termo.</p>
        </div>

        <?= renderizarPaginacao($total, $pagina, $porPagina, array_filter(['status' => $status])) ?>
    <?php endif; ?>
</div>

<p class="texto-pequeno texto-secundario">
    Você pode cancelar pelo painel até o horário do atendimento. Cancelando até <?= (int) $minutosSemPerda ?> min antes,
    o sinal pago fica como crédito para o próximo agendamento. Depois disso, ou se o sinal já veio de um cancelamento
    anterior, ele fica com o estabelecimento.
</p>

<!-- Modal de detalhes -->
<?php /* Janela controlada pelo JavaScript para detalhes ou ações da página. */ ?><div class="modal" id="modalDetalhes">
    <div class="modal-caixa">
        <div class="modal-cabecalho">
            <h3>Detalhes do agendamento</h3>
            <button type="button" class="modal-fechar" data-fechar-modal aria-label="Fechar">&times;</button>
        </div>
        <div class="modal-corpo">
            <dl class="lista-detalhes">
                <div><dt>Serviço</dt><dd data-preenche="servico">-</dd></div>
                <div><dt>Profissional</dt><dd data-preenche="profissional">-</dd></div>
                <div><dt>Data</dt><dd data-preenche="data">-</dd></div>
                <div><dt>Horário</dt><dd data-preenche="horario">-</dd></div>
                <div><dt>Duração</dt><dd data-preenche="duracao">-</dd></div>
                <div><dt>Valor</dt><dd data-preenche="valor">-</dd></div>
                <div><dt>Status</dt><dd data-preenche="status">-</dd></div>
                <div><dt>Observação</dt><dd data-preenche="observacao">-</dd></div>
            </dl>
        </div>
        <div class="modal-rodape">
            <button type="button" class="btn btn-contorno" data-fechar-modal>Fechar</button>
        </div>
    </div>
</div>

<!-- Modal de cancelamento -->
<?php /* Janela controlada pelo JavaScript para detalhes ou ações da página. */ ?><div class="modal" id="modalCancelar">
    <?php /* Formulário de alteração: os dados serão validados novamente pelo servidor. */ ?><form method="post" class="modal-caixa">
        <?= campoCsrf() ?>
        <input type="hidden" name="acao" value="cancelar">
        <input type="hidden" name="id_agendamento" value="">

        <div class="modal-cabecalho">
            <h3>Cancelar agendamento</h3>
            <button type="button" class="modal-fechar" data-fechar-modal aria-label="Fechar">&times;</button>
        </div>

        <div class="modal-corpo">
            <p>Deseja realmente cancelar o agendamento <strong data-preenche="resumo"></strong>?</p>
            <p class="texto-secundario" data-preenche="aviso"></p>

            <div class="campo">
                <label for="motivo">Motivo (opcional)</label>
                <input type="text" id="motivo" name="motivo" maxlength="200" placeholder="Ex.: imprevisto no trabalho">
            </div>
        </div>

        <div class="modal-rodape">
            <button type="button" class="btn btn-contorno" data-fechar-modal>Voltar</button>
            <button type="submit" class="btn btn-perigo">Confirmar cancelamento</button>
        </div>
    </form>
</div>

<?php require_once RAIZ . '/includes/painel_footer.php'; ?>
