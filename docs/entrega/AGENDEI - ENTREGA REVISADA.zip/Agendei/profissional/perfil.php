<?php
/**
 * Dados pessoais e senha do profissional.
 */
// Carrega as configurações, a sessão e as funções compartilhadas antes de processar a página.
require_once __DIR__ . '/../config/config.php';

// Restringe esta página a profissionais autenticados.
exigirLogin('profissional');

// Obtém o profissional da sessão para restringir os dados à sua própria agenda.
$idProfissional = perfilId();
$idUsuario      = usuarioId();
$profissional   = Profissional::porId($idProfissional);

if (!$profissional) {
    definirFlash('erro', 'Perfil não encontrado.');
    redirecionar('profissional/dashboard.php');
}

$tokenCalendario = Diferencial::tokenCalendario($idProfissional);
$protocolo = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$urlCalendario = $protocolo . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . BASE_URL
    . '/calendario.php?token=' . rawurlencode($tokenCalendario);

$erros = [];

// Processa o formulário enviado antes de montar o HTML da página.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Confere o token da sessão antes de aceitar alterações enviadas pelo formulário.
    exigirCsrf();
    $acao = post('acao');

    // Valida e atualiza as informações pessoais do perfil.
    if ($acao === 'dados') {
        $nome     = post('nome');
        $email    = mb_strtolower(post('email'));
        $telefone = apenasNumeros(post('telefone'));

        if (mb_strlen($nome) < 5 || !str_contains($nome, ' ')) {
            $erros[] = 'Informe seu nome completo.';
        }
        if (!validarEmail($email)) {
            $erros[] = 'Informe um e-mail válido.';
        } elseif (Usuario::emailEmUso($email, $idUsuario)) {
            $erros[] = 'Este e-mail já está em uso por outra conta.';
        }
        if ($telefone !== '' && !in_array(strlen($telefone), [10, 11], true)) {
            $erros[] = 'Informe um telefone válido com DDD.';
        }

        if ($erros === []) {
            Usuario::atualizar($idUsuario, ['nome' => $nome, 'email' => $email, 'telefone' => $telefone]);
            Profissional::atualizar($idProfissional, [
                'especialidade'        => post('especialidade'),
                'bio'                  => post('bio'),
                'pode_bloquear_agenda' => (int) $profissional['pode_bloquear_agenda'],
            ]);

            $_SESSION['usuario_nome']  = $nome;
            $_SESSION['usuario_email'] = $email;

            definirFlash('sucesso', 'Dados atualizados com sucesso.');
            redirecionar('profissional/perfil.php');
        }
    }

    // Encaminha a troca de senha à validação da senha atual e da confirmação.
    if ($acao === 'senha') {
        $erros = alterarSenhaUsuario($idUsuario, post('senha_atual'), post('nova_senha'), post('confirmar_senha'));

        if ($erros === []) {
            definirFlash('sucesso', 'Senha alterada com sucesso.');
            redirecionar('profissional/perfil.php');
        }
    }
}

// Define o título e os demais dados de apresentação utilizados pelo cabeçalho.
$tituloPagina  = 'Meu perfil';
$subtituloTopo = 'Seus dados de cadastro e acesso';
$jsExtra       = ['login.js'];

// Renderiza a estrutura comum do painel após preparar os dados desta tela.
require_once RAIZ . '/includes/painel_header.php';
?>

<?php if ($erros !== []): ?>
    <div class="alerta alerta-erro">
        <div>
            <span class="alerta-texto">Corrija os itens abaixo:</span>
            <ul><?php foreach ($erros as $mensagem): ?><li><?= e($mensagem) ?></li><?php endforeach; ?></ul>
        </div>
    </div>
<?php endif; ?>

<div class="grade-painel-igual">
    <div class="cartao">
        <div class="cartao-cabecalho"><h3>Dados profissionais</h3></div>
        <div class="cartao-corpo">
            <?php /* Formulário de alteração: os dados serão validados novamente pelo servidor. */ ?><form method="post" id="formPerfil" novalidate>
                <?= campoCsrf() ?>
                <input type="hidden" name="acao" value="dados">

                <div class="campo">
                    <label for="nome">Nome completo</label>
                    <input type="text" id="nome" name="nome" value="<?= e($profissional['nome']) ?>" required>
                    <span class="mensagem-campo"></span>
                </div>

                <div class="linha-campos">
                    <div class="campo">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" value="<?= e($profissional['email']) ?>" required>
                        <span class="mensagem-campo"></span>
                    </div>

                    <div class="campo">
                        <label for="telefone">Telefone</label>
                        <input type="tel" id="telefone" name="telefone" data-mascara="telefone"
                               value="<?= e(formatarTelefone($profissional['telefone'])) ?>">
                        <span class="mensagem-campo"></span>
                    </div>
                </div>

                <div class="campo">
                    <label for="especialidade">Especialidade</label>
                    <input type="text" id="especialidade" name="especialidade" maxlength="120"
                           value="<?= e($profissional['especialidade']) ?>">
                </div>

                <div class="campo">
                    <label for="bio">Apresentação</label>
                    <textarea id="bio" name="bio" maxlength="400"><?= e($profissional['bio']) ?></textarea>
                    <span class="ajuda-campo">Texto exibido na página inicial do estabelecimento.</span>
                </div>

                <button type="submit" class="btn">Salvar alterações</button>
            </form>
        </div>
    </div>

    <div>
        <div class="cartao">
            <div class="cartao-cabecalho"><h3>Alterar senha</h3></div>
            <div class="cartao-corpo">
                <?php /* Formulário de alteração: os dados serão validados novamente pelo servidor. */ ?><form method="post" id="formSenha" novalidate>
                    <?= campoCsrf() ?>
                    <input type="hidden" name="acao" value="senha">

                    <div class="campo">
                        <label for="senha_atual">Senha atual</label>
                        <input type="password" id="senha_atual" name="senha_atual" autocomplete="current-password" required>
                        <span class="mensagem-campo"></span>
                    </div>

                    <div class="campo">
                        <label for="nova_senha">Nova senha</label>
                        <input type="password" id="nova_senha" name="nova_senha" autocomplete="new-password" required>
                        <span class="mensagem-campo"></span>
                        <span class="ajuda-campo">Mínimo de 6 caracteres.</span>
                    </div>

                    <div class="campo">
                        <label for="confirmar_senha">Confirmar nova senha</label>
                        <input type="password" id="confirmar_senha" name="confirmar_senha" autocomplete="new-password" required>
                        <span class="mensagem-campo"></span>
                    </div>

                    <button type="submit" class="btn">Alterar senha</button>
                </form>
            </div>
        </div>

        <div class="cartao">
            <div class="cartao-cabecalho"><h3>Informações do cadastro</h3></div>
            <div class="cartao-corpo">
                <dl class="lista-detalhes">
                    <div><dt>Cadastro</dt><dd><?= formatarData($profissional['data_cadastro']) ?></dd></div>
                    <div><dt>Situação</dt><dd><?= badgeStatus($profissional['status']) ?></dd></div>
                    <div>
                        <dt>Bloqueio de agenda</dt>
                        <dd><?= !empty($profissional['pode_bloquear_agenda']) ? 'Permitido' : 'Somente pelo administrador' ?></dd>
                    </div>
                </dl>
            </div>
        </div>
    </div>
</div>

<div class="cartao">
    <div class="cartao-cabecalho"><h3>Sincronizar agenda</h3></div>
    <div class="cartao-corpo">
        <p>Use este endereço privado para assinar seus compromissos no Google Agenda, Outlook ou Apple Calendar.</p>
        <div class="campo"><label for="url_calendario">Endereço iCalendar</label><input id="url_calendario" value="<?= e($urlCalendario) ?>" readonly></div>
        <a class="btn btn-contorno" href="<?= e($urlCalendario) ?>">Baixar calendário</a>
        <p class="ajuda-campo margem-topo">Não compartilhe este endereço: ele permite visualizar sua agenda.</p>
    </div>
</div>

<?php require_once RAIZ . '/includes/painel_footer.php'; ?>
